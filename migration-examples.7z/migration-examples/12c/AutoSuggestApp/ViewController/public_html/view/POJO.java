package view;

import java.io.Serializable;


public class POJO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String value;

    public POJO() {
    }

    public POJO(String value) {
        this.value = value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public boolean equals(Object other) {
        return other instanceof POJO && (value != null) ? value.equals(((POJO) other).value) : (other == this);
    }

    public int hashCode() {
        return value != null ? this.getClass().hashCode() + value.hashCode() : super.hashCode();
    }

    public String toString() {
        return value;
    }
}