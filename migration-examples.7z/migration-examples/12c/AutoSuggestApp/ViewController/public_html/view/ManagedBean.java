package view;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;

import oracle.adf.view.rich.model.AutoSuggestUIHints;

public class ManagedBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<SelectItem> suggestItems1;
    
    private List<SelectItem> suggestItems2;

    public ManagedBean() {
        suggestItems1 = new ArrayList<SelectItem>();
        suggestItems1.add(new SelectItem(new POJO("a"), "a"));
        suggestItems1.add(new SelectItem(new POJO("b"), "b"));

        suggestItems2 = new ArrayList<SelectItem>();
        suggestItems2.add(new SelectItem("c", "c"));
        suggestItems2.add(new SelectItem("d", "d"));
    }

    public List<SelectItem> suggestTest1(FacesContext facesContext, AutoSuggestUIHints autoSuggestHints) {
        return suggestItems1;
    }

    public List<SelectItem> suggestTest2(FacesContext facesContext, AutoSuggestUIHints autoSuggestHints) {
        return suggestItems2;
    }
}